package Controlador;
import Modelo.Reg_ClienteDAO;
import Modelo.Reg_Cliente;
import Vista.Vista;
/**
 *
 * @author Laderson Leon
 */
public class Controlador {
    private Reg_ClienteDAO modelo = new Reg_ClienteDAO();
    private Vista vista;

    public Controlador(){
    }
    
    public Controlador(Reg_ClienteDAO modelo, Vista vista) {
        this.modelo = modelo;
        this.vista = vista;
    }
    
    public void regCliente(Reg_Cliente ct){
        modelo.registrarCliente(ct);
    }
    
}

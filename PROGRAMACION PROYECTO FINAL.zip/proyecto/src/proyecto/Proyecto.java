package proyecto;
import Controlador.Controlador;
import Vista.Vista;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Laderson Leon
 */
public class Proyecto {

    public static void main(String[] args) {
        // TODO code application logic here
        Controlador ct = new Controlador();
        Vista vs = new Vista();
        
        vs.iniciar();
    }
    
}

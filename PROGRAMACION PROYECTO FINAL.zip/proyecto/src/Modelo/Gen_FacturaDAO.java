package Modelo;
/**
 *
 * @author Administrador
 */
public class Gen_FacturaDAO {
    
}
